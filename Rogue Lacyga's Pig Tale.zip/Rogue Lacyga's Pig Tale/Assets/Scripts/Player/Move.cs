﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour
{

    //This will be our maximum speed as we will always be multiplying by 1
    public float maxSpeed = 2f;
    public float JumpSpeed = 10f;
    //a boolean value to represent whether we are facing left or not 
    bool facingLeft = true;

    //to check ground and to have a jumpforce we can change in the editor
    public bool grounded = false;
    public Transform groundCheck;
    float groundRadius = 0.2f;
    public LayerMask whatIsGround;
    public float jumpForce = 700f;


    public float move;
    public float jump;

    public int Shot = -1;

    // Use this for initialization
    void Start()
    {
     
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Rigidbody2D rigidbody2D = this.GetComponent<Rigidbody2D>();
        move = Input.GetAxis("Horizontal");//Gives us of one if we are moving via the arrow keys
                                           //move our Players rigidbody
        jump = Input.GetAxis("Jump");//Si on appuie sur espace
        bool shoot = Input.GetButtonDown("Fire1");
        rigidbody2D.velocity = new Vector3(move * maxSpeed, jump * JumpSpeed );
        
        //set our spee
        //if we are moving left but not facing left flip, and vice versa
        if (move < 0 && !facingLeft)
        {

            Flip();
        }
        else if (move > 0 && facingLeft)
        {
            Flip();
        }

        if (grounded && Input.GetKeyDown(KeyCode.Space))
        {
            grounded = false; 
        }
        if (shoot)
        {
            WeaponScript weapon = GameObject.Find("weapon").GetComponent<WeaponScript>();
            if (weapon != null)
            {
                // false : le joueur n'est pas un ennemi
                weapon.Attack(false);
            }
        }

        

    }


    //flip if needed
    void Flip()
    {

        facingLeft = !facingLeft;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        Shot *= -1;
        transform.localScale = theScale;
    }
}
