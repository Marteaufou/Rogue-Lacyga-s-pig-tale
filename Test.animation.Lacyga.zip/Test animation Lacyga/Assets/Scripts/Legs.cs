﻿using UnityEngine;
using System.Collections;

public class Legs : MonoBehaviour {


    Animator anim;
	// Use this for initialization
	void Start () {
        anim = GetComponent<Animator>();
    }
	
	// Update is called once per frame
	void Update () {
        float move = GameObject.Find("Player").GetComponent<Move>().move;
        anim.SetFloat("Speed", Mathf.Abs(move));
    }
}
