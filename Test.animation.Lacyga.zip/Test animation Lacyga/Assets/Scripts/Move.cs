﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour
{

    //This will be our maximum speed as we will always be multiplying by 1
    public float maxSpeed = 2f;
    //a boolean value to represent whether we are facing left or not 
    bool facingLeft = true;
    //a value to represent our Animator 
    Animator anim;

    public float move;
    // Use this for initialization
    void Start()
    {

        //set anim to our animator
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Rigidbody2D rigidbody2D = this.GetComponent<Rigidbody2D>();
        move = Input.GetAxis("Horizontal");//Gives us of one if we are moving via the arrow keys
                                                 //move our Players rigidbody
        rigidbody2D.velocity = new Vector3(move * maxSpeed, rigidbody2D.velocity.y);

        anim.SetFloat("Speed", Mathf.Abs(move));
        
        
        //set our spee
        //if we are moving left but not facing left flip, and vice versa
        if (move < 0 && !facingLeft)
        {

            Flip();
        }
        else if (move > 0 && facingLeft)
        {
            Flip();
        }
    }

    //flip if needed
    void Flip()
    {

        facingLeft = !facingLeft;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}
